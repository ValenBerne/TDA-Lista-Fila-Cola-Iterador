#include "lista.c"
#include "lista_minipruebas.c"

int main() {
    pruebas_de_los_profes();
    return 0;
}
